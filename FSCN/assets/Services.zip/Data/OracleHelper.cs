﻿using System;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Configuration;

namespace FSCN.Data
{
    public class OracleHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        public static OracleConnection GetConnection()
        {
            return new OracleConnection(connectionString);
        }

        // Execute Non-Query (INSERT, UPDATE, DELETE)
        public static int ExecuteNonQuery(string query, params OracleParameter[] parameters)
        {
            using (OracleConnection conn = GetConnection())
            {
                conn.Open();
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        // Execute Scalar
        public static object ExecuteScalar(string query, params OracleParameter[] parameters)
        {
            using (OracleConnection conn = GetConnection())
            {
                conn.Open();
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    return cmd.ExecuteScalar();
                }
            }
        }

        // Get DataReader
        public static OracleDataReader ExecuteReader(string query, params OracleParameter[] parameters)
        {
            OracleConnection conn = GetConnection();
            conn.Open();
            OracleCommand cmd = new OracleCommand(query, conn);
            cmd.Parameters.AddRange(parameters);
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        // Get DataTable
        public static DataTable GetDataTable(string query, params OracleParameter[] parameters)
        {
            DataTable dt = new DataTable();
            using (OracleConnection conn = GetConnection())
            {
                conn.Open();
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }
    }
}