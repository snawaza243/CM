﻿using FSCN.Data;
using FSCN.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Web.Helpers;
using BCrypt.Net;
using FSCN.Helpers;



namespace FSCN.Controllers
{
    public class TempUserService
    {
        // Register new user
        public (bool success, string message, DataTable data) Register(TempUserMaster user)
        {
            try
            {
                if (user == null)
                    return (false, "User data is empty", null);

                // Hash the password
                string hashedPassword = PasswordHelper.HashPassword(user.Password); 


                // Check if email exists
                string checkQuery = "SELECT COUNT(*) FROM TEMP_USER_MASTER WHERE EMAIL = :Email";
                OracleParameter[] checkParams = { new OracleParameter("Email", user.Email) };
                int exists = Convert.ToInt32(OracleHelper.ExecuteScalar(checkQuery, checkParams));

                if (exists > 0)
                    return (false, "Email already registered", null);

                // Insert user
                string insertQuery = @"
                    INSERT INTO TEMP_USER_MASTER 
                    (FIRST_NAME, LAST_NAME, EMAIL, PHONE, PASSWORD_HASH, AGREED_TERMS, MARKETING_OPTIN, CREATED_DATE)
                    VALUES (:FirstName, :LastName, :Email, :Phone, :PasswordHash, :AgreedTerms, :MarketingOptin, SYSDATE)";

                OracleParameter[] insertParams = {
                    new OracleParameter("FirstName", user.FirstName),
                    new OracleParameter("LastName", user.LastName),
                    new OracleParameter("Email", user.Email),
                    new OracleParameter("Phone", user.Phone ?? ""),
                    new OracleParameter("PasswordHash", hashedPassword),
                    new OracleParameter("AgreedTerms", user.AgreedTerms ? 1 : 0),
                    new OracleParameter("MarketingOptin", user.MarketingOptIn ? 1 : 0)
                };

                int rows = OracleHelper.ExecuteNonQuery(insertQuery, insertParams);

                return (rows > 0, "Registration successful", null);
            }
            catch (Exception ex)
            {
                return (false, "Error during registration: " + ex.Message, null);
            }
        }

        // Login user
        public (bool success, string message, DataTable data) Login(string email, string password)
        {
            try
            {
                string query = "SELECT USER_ID, FIRST_NAME, LAST_NAME, EMAIL, PASSWORD_HASH FROM TEMP_USER_MASTER WHERE EMAIL = :Email";
                OracleParameter[] parameters = { new OracleParameter("Email", email) };
                DataTable dt = OracleHelper.GetDataTable(query, parameters);

                if (dt.Rows.Count == 0)
                    return (false, "Invalid email or password", null);

                string storedPassword = dt.Rows[0]["PASSWORD_HASH"].ToString();

                if (PasswordHelper.VerifyPassword(password, storedPassword))
                    return (false, "Invalid email or password", null);

                return (true, "Login successful", dt);
            }
            catch (Exception ex)
            {
                return (false, "Error during login: " + ex.Message, null);
            }
        }

        // Get user by ID
        public (bool success, string message, DataTable data) GetUserById(int userId)
        {
            try
            {
                string query = "SELECT USER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE, AGREED_TERMS, MARKETING_OPTIN FROM TEMP_USER_MASTER WHERE USER_ID = :UserId";
                OracleParameter[] parameters = { new OracleParameter("UserId", userId) };
                DataTable dt = OracleHelper.GetDataTable(query, parameters);

                if (dt.Rows.Count == 0)
                    return (false, "User not found", null);

                return (true, "User retrieved successfully", dt);
            }
            catch (Exception ex)
            {
                return (false, "Error fetching user: " + ex.Message, null);
            }
        }

        // Update user profile
        public (bool success, string message, DataTable data) UpdateUser(TempUserMaster user)
        {
            try
            {
                if (user == null)
                    return (false, "User data is empty", null);

                string query = @"
                    UPDATE TEMP_USER_MASTER
                    SET FIRST_NAME = :FirstName,
                        LAST_NAME = :LastName,
                        PHONE = :Phone,
                        MARKETING_OPTIN = :MarketingOptIn
                    WHERE USER_ID = :UserId";

                OracleParameter[] parameters = {
                    new OracleParameter("FirstName", user.FirstName),
                    new OracleParameter("LastName", user.LastName),
                    new OracleParameter("Phone", user.Phone ?? ""),
                    new OracleParameter("MarketingOptIn", user.MarketingOptIn ? 1 : 0),
                    new OracleParameter("UserId", user.UserId)
                };

                int rows = OracleHelper.ExecuteNonQuery(query, parameters);
                return (rows > 0, "Profile updated successfully", null);
            }
            catch (Exception ex)
            {
                return (false, "Error updating profile: " + ex.Message, null);
            }
        }
    }
}
